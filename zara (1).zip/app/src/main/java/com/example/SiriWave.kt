package com.example

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ZaraOverlayUI(onClose: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)),
        contentAlignment = Alignment.BottomCenter
    ) {
        SiriWave(modifier = Modifier.size(200.dp).padding(bottom = 60.dp))
    }
}

@Composable
fun SiriWave(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "SiriWave")
    
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "time"
    )

    Canvas(
        modifier = modifier
            .graphicsLayer { alpha = 0.9f }
    ) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = size.width / 3

        val cyan = Color(0xFF00F2FE)
        val magenta = Color(0xFFFF0844)
        val neonGreen = Color(0xFF39FF14)

        // Multiple overlapping glowing orbs generated via sine/cosine waves
        drawCircle(
            color = cyan.copy(alpha = 0.5f),
            radius = radius + sin(time * 2) * 20,
            center = Offset(
                center.x + cos(time) * 30,
                center.y + sin(time) * 30
            ),
            blendMode = BlendMode.Screen
        )

        drawCircle(
            color = magenta.copy(alpha = 0.5f),
            radius = radius + cos(time * 3) * 20,
            center = Offset(
                center.x - sin(time) * 20,
                center.y - cos(time * 2) * 20
            ),
            blendMode = BlendMode.Screen
        )

        drawCircle(
            color = neonGreen.copy(alpha = 0.3f),
            radius = radius + sin(time * 1.5f) * 15,
            center = Offset(
                center.x + sin(time * 2) * 15,
                center.y + cos(time * 1.5f) * 15
            ),
            blendMode = BlendMode.Screen
        )
        
        drawCircle(
            color = Color.White.copy(alpha = 0.8f),
            radius = radius * 0.4f,
            center = center,
            blendMode = BlendMode.Screen
        )
    }
}
