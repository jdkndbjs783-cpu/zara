package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val ZaraColorScheme = darkColorScheme(
    primary = NeonCyan,
    secondary = NeonMagenta,
    tertiary = NeonGreen,
    background = DarkSlate,
    surface = DarkSlateSurface,
    surfaceVariant = DarkSlateCard,
    onPrimary = DarkSlate,
    onSecondary = DarkSlate,
    onTertiary = DarkSlate,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark Theme for premium look
    dynamicColor: Boolean = false, // Disable dynamic colors for branding consistency
    content: @Composable () -> Unit,
) {
    MaterialTheme(colorScheme = ZaraColorScheme, typography = Typography, content = content)
}
