package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SiriWave(modifier: Modifier = Modifier, isListening: Boolean = true) {
    val infiniteTransition = rememberInfiniteTransition(label = "SiriWave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val amplitude by infiniteTransition.animateFloat(
        initialValue = if (isListening) 0.5f else 0.1f,
        targetValue = if (isListening) 1.2f else 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "amplitude"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val centerY = h / 2

        // Apple Siri-style glowing orb wave: Cyan, Magenta, Pink, Light Green
        drawWave(color = Color(0xFF00F2FE), phase = phase, amplitude = amplitude, w = w, centerY = centerY, frequency = 1.0f, strokeWidth = 14f)
        drawWave(color = Color(0xFFFF0844), phase = phase + 1.5f, amplitude = amplitude * 1.1f, w = w, centerY = centerY, frequency = 1.3f, strokeWidth = 11f)
        drawWave(color = Color(0xFFFF007F), phase = phase + 3f, amplitude = amplitude * 0.9f, w = w, centerY = centerY, frequency = 1.6f, strokeWidth = 12f)
        drawWave(color = Color(0xFF39FF14), phase = phase + 4.5f, amplitude = amplitude * 0.7f, w = w, centerY = centerY, frequency = 2.1f, strokeWidth = 10f)
    }
}

private fun DrawScope.drawWave(
    color: Color,
    phase: Float,
    amplitude: Float,
    w: Float,
    centerY: Float,
    frequency: Float,
    strokeWidth: Float
) {
    val path = Path()
    val steps = 150
    for (i in 0..steps) {
        val x = w * i / steps
        val normX = (i.toFloat() / steps) * 4f - 2f // -2 to 2
        // attenuation to taper the ends
        val att = 1f / (1f + (normX * normX * normX * normX))
        val y = centerY + sin(normX * Math.PI.toFloat() * frequency + phase) * amplitude * 120f * att
        
        if (i == 0) {
            path.moveTo(x, y)
        } else {
            path.lineTo(x, y)
        }
    }
    
    drawPath(
        path = path,
        color = color.copy(alpha = 0.8f),
        style = Stroke(width = strokeWidth),
        blendMode = BlendMode.Screen
    )
}
