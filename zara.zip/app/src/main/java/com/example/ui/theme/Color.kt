package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00F2FE)
val NeonMagenta = Color(0xFFFF0844)
val NeonGreen = Color(0xFF00FF87)

val DarkSlate = Color(0xFF0B1120)
val DarkSlateSurface = Color(0xFF151E32)
val DarkSlateCard = Color(0xFF1E293B)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
