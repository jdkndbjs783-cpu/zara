package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.ui.theme.MyApplicationTheme

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.SettingsManager
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  @OptIn(ExperimentalMaterial3Api::class)
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val settingsManager = SettingsManager(this)

    setContent {
      MyApplicationTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
          val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
          val scope = rememberCoroutineScope()
          val navController = rememberNavController()


        ModalNavigationDrawer(
          drawerState = drawerState,
          drawerContent = {
            ModalDrawerSheet {
              Spacer(Modifier.height(12.dp))
              NavigationDrawerItem(
                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                label = { Text("Home") },
                selected = false,
                onClick = {
                  scope.launch { drawerState.close() }
                  navController.navigate("home")
                },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
              )
              NavigationDrawerItem(
                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                label = { Text("Settings (\u2699\uFE0F)") },
                selected = false,
                onClick = {
                  scope.launch { drawerState.close() }
                  navController.navigate("settings")
                },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
              )
            }
          }
        ) {
          Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
              TopAppBar(
                title = { Text("Zara Assistant", color = MaterialTheme.colorScheme.primary) },
                navigationIcon = {
                  IconButton(onClick = { scope.launch { drawerState.open() } }) {
                    Icon(Icons.Default.Menu, contentDescription = "Menu", tint = MaterialTheme.colorScheme.primary)
                  }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                  containerColor = MaterialTheme.colorScheme.surface,
                  titleContentColor = MaterialTheme.colorScheme.primary
                )
              )
            }
          ) { innerPadding ->
            NavHost(navController, startDestination = "home", modifier = Modifier.padding(innerPadding).fillMaxSize()) {
              composable("home") {
                HomeScreen()
              }
              composable("settings") {
                SettingsScreen(settingsManager)
              }
            }
          }
        }
        } // Surface end
      }
    }
  }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun HomeScreen() {
  val context = LocalContext.current
  val intent = Intent(context, ZaraListeningService::class.java)

  val permissionsToRequest = mutableListOf(
    Manifest.permission.CAMERA,
    Manifest.permission.RECORD_AUDIO,
    Manifest.permission.CALL_PHONE,
    Manifest.permission.SEND_SMS,
    Manifest.permission.READ_CONTACTS
  )

  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
    permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
  }

  val permissionsState = rememberMultiplePermissionsState(permissionsToRequest)

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(24.dp))
    
    // Prominent Floating Action Button
    ExtendedFloatingActionButton(
      onClick = {
        if (permissionsState.allPermissionsGranted) {
          if (!Settings.canDrawOverlays(context)) {
            val overlayIntent = Intent(
              Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
              Uri.parse("package:${context.packageName}")
            )
            context.startActivity(overlayIntent)
          } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
              context.startForegroundService(intent)
            } else {
              context.startService(intent)
            }
          }
        } else {
          permissionsState.launchMultiplePermissionRequest()
        }
      },
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = MaterialTheme.colorScheme.onPrimary,
      modifier = Modifier.fillMaxWidth().height(64.dp)
    ) {
      Text("Launch Zara Service", style = MaterialTheme.typography.titleMedium)
    }

    Spacer(modifier = Modifier.height(32.dp))
    Text(
        "Automation Modules Status", 
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.align(Alignment.Start)
    )
    Spacer(modifier = Modifier.height(16.dp))

    val isActive = permissionsState.allPermissionsGranted && Settings.canDrawOverlays(context)

    val modules = listOf(
      Pair("Call & SMS Control", Icons.Rounded.PermPhoneMsg),
      Pair("Device Automation", Icons.Rounded.ToggleOn),
      Pair("Web Intelligence", Icons.Rounded.TravelExplore),
      Pair("Background Vision", Icons.Rounded.Camera),
      Pair("Timers & Alarms", Icons.Rounded.Timer),
      Pair("Schedule & Calendar", Icons.Rounded.Event),
      Pair("Utility Toolkit", Icons.Rounded.Calculate),
      Pair("Environment & Weather", Icons.Rounded.WbSunny),
      Pair("Language Translation", Icons.Rounded.Translate),
      Pair("Smart Home Control", Icons.Rounded.Home),
      Pair("Media & Entertainment", Icons.Rounded.Movie)
    )

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      contentPadding = PaddingValues(bottom = 24.dp)
    ) {
      items(modules) { module ->
        Card(
          modifier = Modifier.fillMaxWidth().height(80.dp),
          shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(
             containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
          ),
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
             Icon(
                 imageVector = module.second,
                 contentDescription = module.first,
                 tint = MaterialTheme.colorScheme.primary,
                 modifier = Modifier.size(28.dp)
             )
             Spacer(modifier = Modifier.width(16.dp))
             Text(
                 text = module.first,
                 style = MaterialTheme.typography.titleMedium,
                 color = MaterialTheme.colorScheme.onSurface,
                 modifier = Modifier.weight(1f)
             )
             Text(
                 text = if (isActive) "Active" else "Required",
                 style = MaterialTheme.typography.labelLarge.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Bold),
                 color = if (isActive) androidx.compose.ui.graphics.Color(0xFF39FF14) else androidx.compose.ui.graphics.Color(0xFFFF073A)
             )
          }
        }
      }
    }
  }
}

@Composable
fun SettingsScreen(settingsManager: SettingsManager) {
  var geminiKey by remember { mutableStateOf(settingsManager.getGeminiKey() ?: "") }
  var groqCloudKey by remember { mutableStateOf(settingsManager.getGroqCloudKey() ?: "") }
  var openRouterKey by remember { mutableStateOf(settingsManager.getOpenRouterKey() ?: "") }
  val context = LocalContext.current

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(24.dp)
      .imePadding()
      .verticalScroll(androidx.compose.foundation.rememberScrollState()),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(
        "API Configurations",
        style = MaterialTheme.typography.headlineSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.align(Alignment.Start)
    )
    Spacer(modifier = Modifier.height(24.dp))
    OutlinedTextField(
      value = geminiKey,
      onValueChange = { geminiKey = it },
      label = { Text("Gemini API Key") },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant
      )
    )
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
      value = groqCloudKey,
      onValueChange = { groqCloudKey = it },
      label = { Text("GroqCloud API Key") },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant
      )
    )
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
      value = openRouterKey,
      onValueChange = { openRouterKey = it },
      label = { Text("OpenRouter API Key") },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant
      )
    )
    Spacer(modifier = Modifier.height(40.dp))
    Button(
      onClick = {
        settingsManager.saveGeminiKey(geminiKey)
        settingsManager.saveGroqCloudKey(groqCloudKey)
        settingsManager.saveOpenRouterKey(openRouterKey)
        android.widget.Toast.makeText(context, "Settings Saved!", android.widget.Toast.LENGTH_SHORT).show()
      },
      modifier = Modifier.fillMaxWidth().height(56.dp),
      shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
    ) {
      Text("Save Settings", style = MaterialTheme.typography.titleMedium)
    }
  }
}

