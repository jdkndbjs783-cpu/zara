package com.example

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class ApiKeyManager(context: Context) {

    private val sharedPreferences: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "zara_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Throwable) {
            // Fallback to regular SharedPreferences if EncryptedSharedPreferences fails (common on some emulators)
            context.getSharedPreferences("zara_fallback_prefs", Context.MODE_PRIVATE)
        }
    }

    fun saveGeminiKey(key: String) {
        sharedPreferences.edit().putString("GEMINI_KEY", key).apply()
    }

    fun getGeminiKey(): String {
        return sharedPreferences.getString("GEMINI_KEY", "") ?: ""
    }

    fun saveGroqKey(key: String) {
        sharedPreferences.edit().putString("GROQ_KEY", key).apply()
    }

    fun getGroqKey(): String {
        return sharedPreferences.getString("GROQ_KEY", "") ?: ""
    }

    fun saveOpenRouterKey(key: String) {
        sharedPreferences.edit().putString("OPENROUTER_KEY", key).apply()
    }

    fun getOpenRouterKey(): String {
        return sharedPreferences.getString("OPENROUTER_KEY", "") ?: ""
    }
}
