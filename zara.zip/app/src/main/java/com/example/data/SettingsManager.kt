package com.example.data

import android.content.Context
import android.content.SharedPreferences

class SettingsManager(context: Context) {
    // Falling back to standard SharedPreferences to fix immediate saving glitches when UI unmounts
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        "zara_secure_prefs", Context.MODE_PRIVATE
    )

    fun saveGeminiKey(key: String) {
        sharedPreferences.edit().putString("GEMINI_KEY", key).commit() // using commit for immediate cross-session persistence
    }

    fun getGeminiKey(): String? {
        return sharedPreferences.getString("GEMINI_KEY", null)
    }

    fun saveGroqCloudKey(key: String) {
        sharedPreferences.edit().putString("GROQ_KEY", key).commit()
    }

    fun getGroqCloudKey(): String? {
        return sharedPreferences.getString("GROQ_KEY", null)
    }

    fun saveOpenRouterKey(key: String) {
        sharedPreferences.edit().putString("OPENROUTER_KEY", key).commit()
    }

    fun getOpenRouterKey(): String? {
        return sharedPreferences.getString("OPENROUTER_KEY", null)
    }
}
